#ifndef MINDMAP_H
#define MINDMAP_H

#include <QMainWindow>
#include <QGridLayout>

QT_BEGIN_NAMESPACE
namespace Ui { class Mindmap; }
QT_END_NAMESPACE

class Mindmap : public QMainWindow
{
    Q_OBJECT

public:
    Mindmap(QWidget *parent = nullptr);
    ~Mindmap();

    void onAddWidget();

private:
    Ui::Mindmap *ui;
    int count;
    QGridLayout* layout;
};
#endif // MINDMAP_H
