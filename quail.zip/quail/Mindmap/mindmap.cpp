#include "mindmap.h"
#include "ui_mindmap.h"
#include "QTextEdit"

Mindmap::Mindmap(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::Mindmap)
{
    ui->setupUi(this);

    this->count = 1;
    QObject::connect(ui->pushButtonAdd, &QPushButton::clicked, this, &Mindmap::onAddWidget);

    layout = qobject_cast<QGridLayout*>(ui->gridLayout_2->layout());

}

Mindmap::~Mindmap()
{
    delete ui;
}

void Mindmap::onAddWidget() {

    QTextEdit* textEdit = new QTextEdit;

    layout->addWidget(textEdit,0,this->count);
    this->count++;
}
